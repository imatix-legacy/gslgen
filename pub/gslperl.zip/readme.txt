GSLperl

Open Source, free, and at no cost to you...

This implementation of GSL was done in Perl so we could get something off
the ground quickly.  The job was made a lot easier by the Perl XML::Parser
module (see Parser.htm), and by Perl's ability to interpret expressions.
The C implementation of GSLgen needed its own full-blown expression parser.

This also causes a compatability problem: Perl's expressions are not the
same as GSL's (as implemented in GSLgen).  We have:

    .if "$(item)" == ""      in Perl
    .if item = ""            in GSLgen

Also, the XML interpretation of XML::Parser may be more or less rigourous
than that implemented by our own SFL sflxml module.  For instance,
XML::Parser accepts DTDs, while sflxml does not, yet.

Finally, GSLgen is still evolving, while GSLperl is a frozen project.  It
demonstrates a useful 3gcg built using Libero and Perl, and certainly packs
a punch if you want to do intelligent XML handling in Perl without writing
lots of Perl code.  GSL is much better at code generation than Perl.

--
18 June, 1999

Pieter Hintjens
iMatix Corporation
ph@imatix.com
