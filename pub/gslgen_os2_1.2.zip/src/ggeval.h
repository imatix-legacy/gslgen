/*===========================================================================*
 *                                                                           *
 *  ggeval.h     Studio Wizard Generator Schema Parser Header                *
 *                                                                           *
 *  Written:    99/02/28    iMatix <tools@imatix.com>                        *
 *  Revised:    99/02/28                                                     *
 *                                                                           *
 *   Copyright (c) 1996-98 iMatix                                            *
 *                                                                           *
 *   This software is copyright (c) 1996-98 iMatix.  All rights reserved.    *
 *   Use and distribution of this software, documentation, executables,      *
 *   source files, and object files is only permitted in the context of a    *
 *   current License Agreement between the user and iMatix.                  *
 *                                                                           *
 *===========================================================================*/

#ifndef GGEVAL_INCLUDED                /*  Allow multiple inclusions        */
#define GGEVAL_INCLUDED

/*---------------------------------------------------------------------------*/

#include "sfl.h"                        /*  Universal include file           */
#include "ggcomm.h"                     /*  Common declarations              */
#include "ggeval.h"                     /*  Evaluation functions             */
#include "ggpars.h"                     /*  Schema parser header file        */

/*- Functions ---------------------------------------------------------------*/

int evaluate_schema      (SCHEMA_NODE *node);
int evaluate_schema_node (SCHEMA_NODE *node,
			  int shuffle);

/*---------------------------------------------------------------------------*/

#endif



