GSLgen Open Source Edition
--------------------------

This is the full release of GSLgen 1.3, made available as Open Source
Software.  The licence conditions are described in LICENSE.TXT.  Please
read this file.

